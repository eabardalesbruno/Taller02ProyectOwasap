package factoryBrowser;

import org.openqa.selenium.WebDriver;

public interface IBrowser {
    WebDriver create();
}
