package factoryBrowser;

import org.openqa.selenium.WebDriver;

public class Firefox implements IBrowser{
    @Override
    public WebDriver create() {
        return null;
    }
}
