package control;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import session.Session;

public class Control {

    protected By locator;
    protected WebElement control;



    public Control(By locator){
        this.locator = locator;
    }

    public void findControl(){
        control = Session.getSession().getBrowser().findElement(locator);
    }

    public void click(){
        findControl();
        control.click();
    }

    // Método para obtener el texto del control
    public String getText() {
        findControl();
        return control.getText();
    }

    // Método para verificar si el control está habilitado
    public boolean isEnabled() {
        findControl();
        return control.isEnabled();
    }

    // Método para verificar si el control está visible
    public boolean isDisplayed() {
        findControl();
        return control.isDisplayed();
    }

    // Método para enviar texto al control (útil para campos de texto)
    public void setText(String text) {
        findControl();
        control.clear(); // Limpia el campo antes de enviar texto
        control.sendKeys(text);
    }

    // Método para obtener el atributo de un control
    public String getAttribute(String attribute) {
        findControl();
        return control.getAttribute(attribute);
    }

    public boolean isControlDisplayed() {
        try {
            findControl();
            return control.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

}
