package testSuite;

import org.junit.jupiter.api.*;
import pages.LoginSectionTodoIst;
import session.Session;

public class LoginTestTodois {

    private LoginSectionTodoIst loginSection; // Instancia de la clase que maneja el login

    @BeforeEach
    public void openBrowser() {
        // Inicializamos la instancia de LoginSection con la sesión activa
        loginSection = new LoginSectionTodoIst(Session.getSession().getBrowser());

        // Navegar a la página de Todoist
        Session.getSession().getBrowser().get("https://www.todoist.com/es");
    }

    @AfterEach
    public void closeBrowser() {
        // Cerramos la sesión del navegador después de cada prueba
        Session.getSession().closeSession();
    }

    @Test
    @Order(3)
    public void completeFlowTest() {
        // Step 1: Click on "Iniciar sesión"
        loginSection.clickLoginLink();

        // Step 2: Click on "Regístrate"
        loginSection.clickRegisterLink();

        // Step 3: Enter email for registration
        loginSection.registerEmailTextBox("operadornotificaciones.eduardo@gmail.com");

        // Step 4: Enter password for registration
        loginSection.registerPasswordTextBox("12345678!!!BBa");

        // Step 5: Click on buttton "Regístrate"
        loginSection.setButtonRegisterLink();

        // Step 6: Click on button "Regístrate" and verify the error message
        Assertions.assertTrue(
                loginSection.setVerifyRegister(),
                "Expected error message 'Esta direcci'"
        );

        // Step 7: Click on button iniiciar session luego de verificar el mensaje de error
        loginSection.clickbuttondirecional();

        // Step 8: registerEmailTextBoxValidado
        loginSection.registerEmailTextBoxValidado("operadornotificaciones.eduardo@gmail.com");

        // Step 9: registerontraseñaValidada
        loginSection.registerPasswordValidadoTextBox("12345678!!!BBa");

        // Step 10: Click on buttton "Iniciar sesión Final"
        loginSection.Finish();


    }

}
